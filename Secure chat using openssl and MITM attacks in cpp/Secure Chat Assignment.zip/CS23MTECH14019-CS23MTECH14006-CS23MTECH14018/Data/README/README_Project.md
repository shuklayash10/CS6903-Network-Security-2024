
# Project README


## General Commands

Setting 40% loss at client's network card , use the following command :

```
 sudo tc qdisc add dev eth0 root netem loss 40%

```












 







