
# Trudy README


## Used Commands

To Run , use the following command :

```
 ./secure_chat_interceptor -d alice1 bob1

```











 







