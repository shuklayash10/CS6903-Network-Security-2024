
# Alice README



## General Commands : 

 Command :

```
 lxc exec alice1 bash

```


## Usage

To initiate a secure chat, execute the following command :

```
./secure_chat -c bob1

```










 







