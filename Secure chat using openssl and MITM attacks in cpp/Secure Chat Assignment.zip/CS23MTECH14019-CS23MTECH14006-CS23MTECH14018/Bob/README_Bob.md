
# Bob README


## General Command

To Run , use the following command :

```
 lxc exec alice1 bash

```
## Usage

To initiate, execute the following command :

```
./secure_chat_app -s alice1 

```










 







